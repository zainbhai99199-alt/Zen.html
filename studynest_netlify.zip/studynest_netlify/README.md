# StudyNest + Zen AI (Netlify)

- public/index.html          -> StudyNest app
- netlify/functions/ask.mjs  -> Zen AI backend (serverless)

## Deploy (mobile browser se)
1. GitHub par nayi repo banayein, is folder ki saari files upload karein.
2. app.netlify.com -> Add new site -> Import from Git -> apni repo chunein.
3. Site configuration -> Environment variables mein ek key daalein:
   GEMINI_API_KEY (free)  ya  ANTHROPIC_API_KEY
4. Deploys -> Trigger deploy. Phir site kholein aur Zen AI try karein.
