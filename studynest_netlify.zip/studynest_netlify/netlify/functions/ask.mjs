// Zen AI backend for StudyNest (Netlify Function, free tier).
// Env vars: GEMINI_API_KEY (free option)  OR  ANTHROPIC_API_KEY
// Optional: GEMINI_MODEL, ANTHROPIC_MODEL

const SYSTEM =
  "You are Zen AI, a calm, kind study assistant inside the StudyNest app. " +
  "Explain simply with examples, keep answers short, and reply in the same language the student writes in.";

const hits = new Map(); // best-effort rate limit per function instance

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });

async function callGemini(system, history, message) {
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const contents = [...history, { role: "user", content: message }].map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents }),
    }
  );
  if (!r.ok) throw new Error("gemini " + r.status);
  const j = await r.json();
  return (j.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
}

async function callClaude(system, history, message) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 1000,
      system,
      messages: [...history, { role: "user", content: message }],
    }),
  });
  if (!r.ok) throw new Error("claude " + r.status);
  const j = await r.json();
  return (j.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
}

export default async (req) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  if (!process.env.GEMINI_API_KEY && !process.env.ANTHROPIC_API_KEY)
    return json({ error: "API key set nahi hai" }, 500);

  const ip = req.headers.get("x-nf-client-connection-ip") || "unknown";
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 60000);
  if (recent.length >= 20) return json({ error: "Bohat zyada requests, thori der baad try karein" }, 429);
  recent.push(now);
  hits.set(ip, recent);

  let body;
  try { body = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }

  const message = String(body.message || "").trim().slice(0, 4000);
  if (!message) return json({ error: "Empty message" }, 400);

  let history = (Array.isArray(body.history) ? body.history : [])
    .slice(-10)
    .filter((m) => (m.role === "user" || m.role === "assistant") && m.content)
    .map((m) => ({ role: m.role, content: String(m.content).slice(0, 4000) }));
  while (history.length && history[0].role !== "user") history.shift();

  let system = SYSTEM;
  const notes = (Array.isArray(body.notes) ? body.notes : []).slice(0, 5).map((n) => String(n).slice(0, 300));
  if (notes.length) system += "\nThe student's own notes (use if relevant):\n" + notes.join("\n");

  try {
    const reply = process.env.GEMINI_API_KEY
      ? await callGemini(system, history, message)
      : await callClaude(system, history, message);
    return json({ reply });
  } catch (e) {
    return json({ error: "AI service error" }, 502);
  }
};
